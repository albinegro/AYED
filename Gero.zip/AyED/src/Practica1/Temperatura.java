package Practica1;

import java.util.Scanner;

public class Temperatura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println ("Por favor introduzca la temperatura:");
        Scanner entradaEscaner = new Scanner (System.in); //Creaci�n de un objeto Scanner
		System.out.print(calcularCelsius(entradaEscaner.nextInt()));
		
		
	}
	
	public static int calcularCelsius(int temp){
		return ((temp-32)*5)/9;
	}
}
