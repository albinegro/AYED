package Practica1;

public class Bienvenida {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.print("Hola ");
		System.out.print(args[0]+ " ");
		System.out.print(args[1]);
	}

}
